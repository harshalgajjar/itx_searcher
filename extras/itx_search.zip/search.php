<?php
  if(isset($_GET['livekeyword'])){
    $keyword=$_GET['livekeyword'];
    $current_words = file('data/itx_words.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $all_words = implode(" ",$current_words);

    $search_regex= "/\b" . $keyword . "[a-zA-Z^]*\b/";

    preg_match_all($search_regex, $all_words, $suggested_words, PREG_OFFSET_CAPTURE);

    for($i=0; $i<sizeof($suggested_words[0]); $i++){
      if($i>5) break;
      echo "<span class='suggested-word' onclick='suggestionClicked(this.innerHTML)'>" . $suggested_words[0][$i][0] . "</span><br />";
    }
  }else if(isset($_GET['keyword'])){

    $itx_data = file('data/itx_data.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $keyword=$_GET['keyword'];

    $word_found=0;

    for($i=0; $i<sizeof($itx_data); $i++){
      $word=explode(" ",$itx_data[$i])[0];

      if($keyword==$word){
        $word_found=1;
        $locations=array_slice(explode(" ",$itx_data[$i]),1);
        echo sizeof($locations) . " results found<br /><br />";
        for($j=0; $j<sizeof($locations); $j++){
          echo "<div class='one-result' id='result" . "$j' onclick='oneResultClicked($locations[$j], $j)'>" . $locations[$j] .
          "<br /><a href='$locations[$j]' target='_blank'>Visit</a>" .
          "</div>";
        }
      }

    }
  }
?>

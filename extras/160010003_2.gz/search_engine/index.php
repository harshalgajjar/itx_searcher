<?php

echo file_get_contents("http://fromabctill.xyz");

?>

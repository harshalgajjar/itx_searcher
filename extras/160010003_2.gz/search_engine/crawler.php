<?php
  //$html="<a href='http://fromabctill.xyz'></a> <a href='http://fromabctill.xyz/contact'></a> <a href='http://fromabctill.xyz/projects'></a>'";

  $url="https://sanskritdocuments.org/";
  $url_subpath="";
  $url_last_word="";

  if($url[strlen($url)-1]=="/"){
    $url=substr($url,0,strlen($url)-1);
  }

  $html=file_get_contents($url);

  preg_match_all('/(href[\ ]*=[\ ]*)["\']+[^\'"]*["\']+/', $html, $matches, PREG_OFFSET_CAPTURE);
  preg_match('/.*[\/]/',$url,$url_subpath, PREG_OFFSET_CAPTURE); $url_subpath=$url_subpath[0][0]; if($url_subpath=="https://" || $url_subpath=="http://") $url_subpath=$url."/";
  preg_match('/\/[^\/]+$/',$url,$url_last_word, PREG_OFFSET_CAPTURE); $url_last_word=$url_last_word[0][0]; $url_last_word=substr($url_last_word,1);

  echo $url . "<br />";
  echo "subpath= " . $url_subpath . "<br />";
  echo "last_word= " . $url_last_word . "<br />";
  echo "<br />";

  // echo 'size of $matches=' . sizeof($matches[0][0][0][0]) . "<br />";
  // echo '$matches[0][0][0][0]=' . $matches[0][0][0];

  for($i=0;$i<sizeof($matches[0]);$i++){
    $matches[0][$i][0]=preg_replace('/href[\ ]*=[\ ]*[\"\ \']*/', '', $matches[0][$i][0]); //https?:\/\/
    $matches[0][$i][0]=preg_replace('/[\[^"\]+]$/', '', $matches[0][$i][0]);

    if($matches[0][$i][0][0]=="/"){
      //echo $matches[0][$i][0] . "->";
      $matches[0][$i][0]= $url_subpath . substr($matches[0][$i][0],1);
      //echo $matches[0][$i][0] . "</br >";
    }else if($matches[0][$i][0]=="#"){
      //echo $matches[0][$i][0] . "->";
      $matches[0][$i][0]= $url;
      //echo $matches[0][$i][0] . "</br >";
    }else if(strpos($matches[0][$i][0],"http") === false){
      //echo $matches[0][$i][0] . "->";
      $matches[0][$i][0]=$url_subpath . $matches[0][$i][0];
      //echo $matches[0][$i][0] . "<br />";
    }else{
      //echo $matches[0][$i][0] . "</br >";
    }

    if($matches[0][$i][0][strlen($matches[0][$i][0])-1]=="/"){
      //echo $matches[0][$i][0] . "->";
      $matches[0][$i][0]= substr($matches[0][$i][0],0,strlen($matches[0][$i][0])-1);
      //echo $matches[0][$i][0] . "</br >";
    }

  }
  //echo "<br />";

  // if(isset($_POST['start_submit'])){
  //
  // }
  // print_r($matches);

  //echo "<br/>";
?>
<html>
<head>
</head>
<body>
  <form action="" method="POST">
    <input type="text" name="start" />
    <input type="submit" name="start_submit" />
  </form>
</body>
</html>
